MUJIV STORE — static app discovery portal

Upload the CONTENTS of this folder to the ROOT of your GitHub repository.
The file index.html must be at the repository root (not inside another folder).

GitHub Pages:
Repository > Settings > Pages
Build and deployment: Deploy from a branch
Branch: main
Folder: /(root)
Save, then wait for the published URL.

The search opens live search pages on each source. It does not merge all source results into one database; most listed sites do not provide a common public search API. Verify APK publisher, signature, permissions and legality before installing.
