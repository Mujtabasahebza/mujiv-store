MUJIV STORE — SUPER EDITION

What this does
- UI language: English.
- Accepts search text in many languages.
- Attempts translation to English using MyMemory (free browser endpoint, quota-limited). Keeps the original query and searches it too.
- Live results in-page:
  1. F-Droid official app search API (free/open-source Android apps)
  2. GitHub repository search API (developer projects; may not contain APK)
  3. GitLab public project listing API (developer projects; may not contain APK)
- Results priority: F-Droid free/open-source first, then GitHub/GitLab projects.
- Additional site-specific searches for Google Play, Uptodown, APKMirror, APKPure, APKCombo, APKFab, Aptoide, PlatinMods, Mobilism, HappyMod, LiteAPKs, APKDone, RockMods, Modyolo, APKVision, 4PDA, Androeed, Farsroid, AN1 and Sbenny.

How to activate on Android (recommended)
1. Download this ZIP and extract it with File Manager.
2. Open Chrome and visit https://app.netlify.com/drop
3. Upload the ZIP file OR the extracted folder. The ZIP contains index.html at its root and the _redirects file.
4. Netlify publishes the site and gives you a URL ending in netlify.app.
5. Open that URL in Chrome.
6. Tap Chrome ⋮ > Install app (or Add to Home screen).
7. Start searching. Keep internet on.

Quick test
- Search `F-Droid` or `Firefox` to test the live F-Droid API.
- Search `VLC` or `Signal` to test open-source results.
- Search in Persian/Arabic/Russian/Chinese to test best-effort English translation.
- If translation fails, original-language search continues.

Important engineering facts
- Websites without public APIs are not scraped or represented as live API results. Their dedicated site-search links are provided.
- F-Droid is a bona fide free/open-source repository. GitHub/GitLab results are project pages and may require checking Releases to find an Android APK.
- MyMemory translation is free within a published daily quota; language-pair availability varies.
- Search APIs have their own rate limits and network restrictions.
- No app can safely promise that every APK/mod site on the internet is included or that every unofficial APK is safe.
- This is a PWA web app, not a native APK installer. It does not host APK files or unlock paid services.
